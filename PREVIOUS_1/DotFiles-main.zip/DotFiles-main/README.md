# DotFiles

not entirely mine/made by me; I have taken from various places on the net.
:warning: risk of falling objects, since this is under construction! :warning:


<details><summary> todo </summary>
  
- [ ] add sources
- [ ] add pros cons, variations
- [ ] verify/check
- [ ] improve
- [ ] document
- [ ] better NAMES (var names, func names, ...)
- [ ] AUTO REPLACE tool to replace e.g YOU with YOUR_USERNAME
- [ ] more GREPS and SEARCHERS (hashes, links, IPS)
- [ ] more LANGS (lua, bash -c, sh -c, perl -..  ruby -,,  )

</details>
