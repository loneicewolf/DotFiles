#### TODO make chocies etc popups

- b3(SHIFT CTRL E)

```sh
#!/bin/sh
base32 
```


- b3d (SHIFT CTRL D)

```sh
#!/bin/sh
base32 -d 
```


