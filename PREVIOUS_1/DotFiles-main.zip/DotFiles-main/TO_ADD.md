# markdown dropdown



***

### ABC

<details>
<summary> Click to expand </summary>
  
  - A
  - B
  - C
  
</details>

***


```

***

### ABC

<details>
<summary> Click to expand </summary>
  
  - A
  - B
  - C
  
</details>

***

```
